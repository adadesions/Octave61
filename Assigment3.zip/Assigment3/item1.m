function item1()
  % 1st
  fprintf('1. 2^8 = %d\n', 2^8);
  
  % 2nd
  fprintf('2. 22/7 - pi = %.4f\n', 22/7- pi);
  
  % 3rd
  x = power(9^2+19^2/22, 1/4) - pi
  fprintf('3. x3 = %.f\n', x);
  
  % 4th
  x = pi - exp(pi);
  fprintf('4. x4 = %f\n', x);
  
  % 5th
  fprintf('5. log10(2) = %.2f\n', log10(2));
  
  % 6 th
  fprintf('6. tanh(e) = %.2f\n', tanh(exp(1)));
end